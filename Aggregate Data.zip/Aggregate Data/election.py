# Enhanced Electoral Prediction Model (with optional individuals, optional 2020, nominal booth id)
# Files are saved with AssemblyName-prefixed filenames (including the .pkl).
import os
import re
import warnings
import itertools
import pickle
from collections import defaultdict

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
import torch.optim as optim

from sklearn.preprocessing import StandardScaler
from sklearn.feature_extraction import DictVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error

warnings.filterwarnings('ignore')

# Reproducibility
np.random.seed(42)
torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed(42)
    # optional deterministic behavior (slower):
    # torch.backends.cudnn.deterministic = True
    # torch.backends.cudnn.benchmark = False

# ---------------------------
# Utilities
# ---------------------------

def sanitize_filename_part(s: str) -> str:
    s = str(s).strip()
    s = re.sub(r'\s+', '_', s)           # spaces -> underscore
    s = re.sub(r'[^A-Za-z0-9_\-]+', '', s)  # keep safe chars
    return s or "Assembly"

def derive_assembly_name_prefix(df: pd.DataFrame) -> str:
    if 'AssemblyName' in df.columns and df['AssemblyName'].notna().any():
        # pick the most frequent assembly name (or first unique)
        val_counts = df['AssemblyName'].dropna().value_counts()
        assembly = val_counts.index[0] if len(val_counts) else "Assembly"
    else:
        assembly = "Assembly"
    return sanitize_filename_part(assembly) + "_"

# ---------------------------
# Model
# ---------------------------

class AggregateVotingModel(nn.Module):
    """
    Aggregate Likelihood Model
    π_ic = σ(α0 + b_i^(T) + x_ic^T β_T)
    θ_ic = softmax(γ0 + b_i^(P) + x_ic^T β_P)
    """
    def __init__(self, n_features, n_parties, n_booths, device='cpu'):
        super().__init__()
        self.device = device

        self.alpha0 = nn.Parameter(torch.randn(1, device=device))
        self.beta_T = nn.Parameter(torch.randn(n_features, device=device))
        self.booth_effects_T = nn.Parameter(torch.randn(n_booths, device=device))

        self.gamma0 = nn.Parameter(torch.randn(n_parties, device=device))
        self.beta_P = nn.Parameter(torch.randn(n_features, n_parties, device=device))
        self.booth_effects_P = nn.Parameter(torch.randn(n_booths, n_parties, device=device))

        self.n_parties = n_parties
        self.n_booths = n_booths
        # keep party names on the model to avoid attribute errors elsewhere
        self.party_names = ['BJP', 'Congress', 'AAP', 'Others', 'NOTA']

    def forward(self, features, booth_indices):
        batch_size = features.shape[0]
        features = features.to(self.device)
        booth_indices = booth_indices.to(self.device)

        turnout_logits = (self.alpha0
                          + self.booth_effects_T[booth_indices]
                          + features @ self.beta_T)
        turnout_probs = torch.sigmoid(turnout_logits)

        party_logits = (self.gamma0.unsqueeze(0).expand(batch_size, -1)
                        + self.booth_effects_P[booth_indices]
                        + features @ self.beta_P)
        party_log_probs = torch.log_softmax(party_logits, dim=1)
        party_probs = torch.exp(party_log_probs)
        return turnout_probs, party_probs, party_log_probs

# ---------------------------
# Data Processor
# ---------------------------

class ElectoralDataProcessor:
    def __init__(self):
        self.vectorizer = DictVectorizer(sparse=False)
        self.scaler = StandardScaler()
        self.booth_id_to_idx = {}
        self.party_names = ['BJP', 'Congress', 'AAP', 'Others', 'NOTA']
        self.correction_log = []
        self.is_fitted = False
        self.booth_metadata = {}

        self.demographic_axes = {
            'age': ['Age_18-25_Ratio', 'Age_26-35_Ratio', 'Age_36-45_Ratio', 'Age_46-60_Ratio', 'Age_60+_Ratio'],
            'religion': ['Religion_Buddhist_Ratio', 'Religion_Christian_Ratio', 'Religion_Hindu_Ratio',
                         'Religion_Jain_Ratio', 'Religion_Muslim_Ratio', 'Religion_Sikh_Ratio'],
            'caste': ['Caste_Brahmin_Ratio', 'Caste_Kshatriya_Ratio', 'Caste_Obc_Ratio',
                      'Caste_Sc_Ratio', 'Caste_St_Ratio', 'Caste_Vaishya_Ratio', 'Caste_No_caste_system_Ratio'],
            'income': ['income_low_ratio', 'income_middle_ratio', 'income_high_ratio']
        }

    def validate_data_columns(self, df):
        required = {
            'basic': ['PartNo', 'AssemblyNo', 'AssemblyName', 'TotalPop', 'Total_Polled', 'Locality'],
            'economic': ['economic_category', 'land_rate_per_sqm', 'construction_cost_per_sqm'],
            'gender': ['Male_Ratio', 'Female_Ratio', 'MaleToFemaleRatio'],
            'age': ['Age_18-25_Ratio', 'Age_26-35_Ratio', 'Age_36-45_Ratio', 'Age_46-60_Ratio', 'Age_60+_Ratio'],
            'religion': ['Religion_Buddhist_Ratio', 'Religion_Christian_Ratio', 'Religion_Hindu_Ratio',
                         'Religion_Jain_Ratio', 'Religion_Muslim_Ratio', 'Religion_Sikh_Ratio'],
            'caste': ['Caste_Brahmin_Ratio', 'Caste_Kshatriya_Ratio', 'Caste_No_caste_system_Ratio',
                      'Caste_Obc_Ratio', 'Caste_Sc_Ratio', 'Caste_St_Ratio', 'Caste_Vaishya_Ratio'],
            'parties': ['BJP_Ratio', 'Congress_Ratio', 'AAP_Ratio', 'Others_Ratio', 'NOTA_Ratio']
        }
        missing = []
        cols = set(df.columns)
        for grp, req_cols in required.items():
            for c in req_cols:
                if c not in cols:
                    missing.append((grp, c))
        if missing:
            print("❌ MISSING REQUIRED COLUMNS:")
            for grp, c in missing:
                print(f"  {grp}: {c}")
            print("\n📋 AVAILABLE COLUMNS:")
            for i, c in enumerate(sorted(cols), 1):
                print(f"  {i:2d}. {c}")
            return False
        print("✅ All required columns found.")
        return True

    def load_and_combine_data(self, file_2025, file_2020=None):
        """Load 2025 (required) and 2020 (optional) data, validate, clean."""
        df_2025 = pd.read_excel(file_2025).copy()
        df_2025['Year'] = 2025

        if file_2020 is not None and os.path.exists(file_2020):
            df_2020 = pd.read_excel(file_2020).copy()
            df_2020['Year'] = 2020
            combined = pd.concat([df_2020, df_2025], ignore_index=True)
            print(f"Loaded: 2020={len(df_2020)}, 2025={len(df_2025)} rows")
        else:
            combined = df_2025
            print(f"Loaded: 2025={len(df_2025)} rows (no 2020 file provided)")

        # Synthesize missing unknown columns to be safe
        for col in ['Religion_Unknown_Ratio', 'Caste_Unknown_Ratio']:
            if col not in combined.columns:
                combined[col] = 0.0
                self.correction_log.append(f"Synthesized missing column {col} as 0.0")

        print("Validating dataset columns...")
        if not self.validate_data_columns(combined):
            raise ValueError("❌ CRITICAL ERROR: Missing required columns.")

        combined = self._clean_and_validate_data(combined)
        return combined

    def _validate_economic_categories(self, df):
        if 'economic_category' in df.columns:
            econ_counts = df['economic_category'].value_counts(dropna=False)
            print("\nEconomic categories found:")
            for k, v in econ_counts.items():
                lab = k if pd.notna(k) else "__MISSING__"
                print(f"  {lab}: {v} rows ({v/len(df)*100:.1f}%)")
        else:
            print("ERROR: No 'economic_category' column found!")
            self.correction_log.append("WARNING: No economic_category column found")
        return df

    def _suppress_unknown_and_renormalize(self, df):
        print("Suppressing Unknown categories and renormalizing...")

        # Religion: zero Unknown, renormalize known religion cols
        rel_known = [c for c in df.columns if c.startswith('Religion_') and c.endswith('_Ratio') and 'Unknown' not in c]
        if 'Religion_Unknown_Ratio' in df.columns:
            df['Religion_Unknown_Ratio'] = 0.0
            denom = df[rel_known].sum(axis=1)
            uniform = 1.0 / max(len(rel_known), 1)
            for c in rel_known:
                df.loc[denom > 0, c] = df.loc[denom > 0, c] / denom[denom > 0]
                df.loc[denom == 0, c] = uniform
            self.correction_log.append("Suppressed Religion_Unknown and renormalized known religions")

        # Caste: zero Unknown, Hindu-only handling later
        if 'Caste_Unknown_Ratio' in df.columns:
            df['Caste_Unknown_Ratio'] = 0.0
            self.correction_log.append("Suppressed Caste_Unknown (handled within-Hindu later)")
        return df

    def _create_income_categories(self, df):
        print("Creating income categories (from economic_category or land_rate fallback)...")
        mapping = {
            'LOW INCOME AREAS': 'income_low',
            'LOWER MIDDLE CLASS': 'income_middle',
            'MIDDLE CLASS': 'income_middle',
            'UPPER MIDDLE CLASS': 'income_high',
            'PREMIUM AREAS': 'income_high'
        }
        for c in ['income_low_ratio', 'income_middle_ratio', 'income_high_ratio']:
            df[c] = 0.0

        for econ, inc in mapping.items():
            mask = (df['economic_category'] == econ)
            df.loc[mask, f'{inc}_ratio'] = 1.0
            if mask.any():
                print(f"  Mapped {mask.sum()} rows '{econ}' -> '{inc}'")

        inc_cols = ['income_low_ratio', 'income_middle_ratio', 'income_high_ratio']
        no_cat = (df[inc_cols].sum(axis=1) == 0)
        if no_cat.any():
            print(f"  Land rate fallback for {no_cat.sum()} rows")
            land = df.loc[no_cat, 'land_rate_per_sqm'].fillna(df['land_rate_per_sqm'].median())
            low_th = land.quantile(0.33)
            high_th = land.quantile(0.67)
            idx = df.index[no_cat]
            df.loc[idx[land <= low_th], 'income_low_ratio'] = 1.0
            df.loc[idx[(land > low_th) & (land <= high_th)], 'income_middle_ratio'] = 1.0
            df.loc[idx[land > high_th], 'income_high_ratio'] = 1.0
            self.correction_log.append(f"Used land rate fallback for {no_cat.sum()} rows")

        sums = df[inc_cols].sum(axis=1)
        assert np.allclose(sums.values, 1.0), "Income one-hots must sum to 1"
        return df

    def _clean_and_validate_data(self, df):
        print("Cleaning and validating data...")
        df = self._validate_economic_categories(df)

        # Fill categorical missing with sentinel
        for col in ['economic_category', 'Locality', 'AssemblyName']:
            if col in df.columns:
                m = df[col].isna()
                if m.any():
                    df.loc[m, col] = "__MISSING__"
                    self.correction_log.append(f"Imputed {m.sum()} missing in {col}")

        # Fill numeric missing
        num_cols = [c for c in df.columns if c.endswith('_Ratio') or c in
                    ['TotalPop', 'Total_Polled', 'land_rate_per_sqm', 'construction_cost_per_sqm', 'MaleToFemaleRatio']]
        for c in num_cols:
            if c in df.columns:
                m = df[c].isna()
                if m.any():
                    df.loc[m, c] = (1e-6 if c.endswith('_Ratio') else df[c].median())
                    self.correction_log.append(f"Imputed {m.sum()} missing in {c}")

        # Fix negatives
        ratio_cols = [c for c in df.columns if c.endswith('_Ratio')]
        for c in ratio_cols:
            neg = df[c] < 0
            if neg.any():
                df.loc[neg, c] = 1e-6
                self.correction_log.append(f"Corrected {neg.sum()} negatives in {c}")

        # Suppress Unknown + renorm religion; caste handled within Hindu later
        df = self._suppress_unknown_and_renormalize(df)

        # Normalize Age & Religion (skip caste here to avoid contradicting within-Hindu plan)
        for axis_name, cols in [('Age', self.demographic_axes['age']), ('Religion', self.demographic_axes['religion'])]:
            exist = [c for c in cols if c in df.columns]
            if exist:
                sums = df[exist].sum(axis=1)
                mask = (sums < 0.98) | (sums > 1.02)
                if mask.any():
                    df.loc[mask, exist] = df.loc[mask, exist].div(sums[mask], axis=0)
                    self.correction_log.append(f"Normalized {axis_name} for {mask.sum()} rows")

        # Normalize party shares
        party_cols = [f'{p}_Ratio' for p in self.party_names if f'{p}_Ratio' in df.columns]
        if party_cols:
            sums = df[party_cols].sum(axis=1)
            mask = (sums < 0.98) | (sums > 1.02)
            if mask.any():
                df.loc[mask, party_cols] = df.loc[mask, party_cols].div(sums[mask], axis=0)
                self.correction_log.append(f"Normalized party shares for {mask.sum()} rows")

        # Booth IDs
        df['booth_nominal_id'] = df['PartNo'].astype(str)          # nominal string for reporting
        df['booth_id'] = df['PartNo'].astype(str) + '_' + df['Year'].astype(str)  # panel id used in model
        unique_booth_ids = df['booth_id'].unique()
        self.booth_id_to_idx = {bid: idx for idx, bid in enumerate(unique_booth_ids)}
        df['booth_idx'] = df['booth_id'].map(self.booth_id_to_idx)

        # Income one-hots
        df = self._create_income_categories(df)
        return df

    def construct_cells(self, df):
        print("Constructing demographic cells...")
        cells_data = []
        booth_cell_indices = defaultdict(list)
        booth_weights = defaultdict(list)

        for _, row in df.iterrows():
            booth_id = row['booth_id']
            booth_idx = row['booth_idx']
            N_i = row['TotalPop']
            T_i = row['Total_Polled']
            if not pd.notna(N_i) or N_i <= 0:
                self.correction_log.append(f"Booth {booth_id}: invalid N_i={N_i}, skip")
                continue

            t_i = T_i / N_i if N_i > 0 else 0.0
            party_shares_raw = {p: float(row.get(f'{p}_Ratio', 0.0)) for p in self.party_names}
            total_share = sum(party_shares_raw.values())
            party_shares = {p: (party_shares_raw[p] / total_share) if total_share > 0 else 1.0/len(self.party_names)
                            for p in self.party_names}

            # Age/Religion/Caste maps
            age_props = {c: float(row.get(c, 0.0)) for c in self.demographic_axes['age']}
            religion_props = {c: float(row.get(c, 0.0)) for c in self.demographic_axes['religion']}
            caste_props = {c: float(row.get(c, 0.0)) for c in self.demographic_axes['caste']}
            income_props = {
                'income_low_ratio': float(row['income_low_ratio']),
                'income_middle_ratio': float(row['income_middle_ratio']),
                'income_high_ratio': float(row['income_high_ratio']),
            }

            self.booth_metadata[booth_idx] = {
                'booth_id': booth_id,
                'N_i': float(N_i),
                'T_i': float(T_i),
                't_i': float(t_i),
                'p_i': party_shares
            }

            hindu_caste_keys = [k for k in caste_props.keys()
                                if k.startswith('Caste_') and k != 'Caste_No_caste_system_Ratio']
            den_hindu = sum(caste_props.get(k, 0.0) for k in hindu_caste_keys)
            caste_given_hindu = {k: (caste_props.get(k, 0.0) / den_hindu if den_hindu > 0 else 1.0/max(len(hindu_caste_keys), 1))
                                 for k in hindu_caste_keys}

            cells_for_booth = []
            for age_col in self.demographic_axes['age']:
                for religion_col in self.demographic_axes['religion']:
                    if religion_col == 'Religion_Hindu_Ratio':
                        for caste_col in hindu_caste_keys:
                            for income_col in self.demographic_axes['income']:
                                caste_factor = caste_given_hindu.get(caste_col, 0.0)
                                n_ic = (N_i * age_props[age_col] * religion_props[religion_col]
                                        * caste_factor * income_props[income_col])
                                cells_for_booth.append({
                                    'n_ic': n_ic,
                                    'age_cat': age_col.replace('_Ratio', ''),
                                    'religion_cat': religion_col.replace('_Ratio', ''),
                                    'caste_cat': caste_col.replace('_Ratio', ''),
                                    'income_cat': income_col.replace('_ratio', '')
                                })
                    else:
                        caste_col = 'Caste_No_caste_system_Ratio'
                        for income_col in self.demographic_axes['income']:
                            n_ic = (N_i * age_props[age_col] * religion_props[religion_col]
                                    * 1.0 * income_props[income_col])
                            cells_for_booth.append({
                                'n_ic': n_ic,
                                'age_cat': age_col.replace('_Ratio', ''),
                                'religion_cat': religion_col.replace('_Ratio', ''),
                                'caste_cat': caste_col.replace('_Ratio', ''),
                                'income_cat': income_col.replace('_ratio', '')
                            })

            valid_cells = [c for c in cells_for_booth if c['n_ic'] >= 0.2]
            drop_cnt = len(cells_for_booth) - len(valid_cells)

            if valid_cells:
                total_w = sum(c['n_ic'] for c in valid_cells)
                if total_w > 0:
                    renorm = N_i / total_w
                    for c in valid_cells:
                        c['n_ic'] *= renorm
                total_after = sum(c['n_ic'] for c in valid_cells)
                if abs(total_after - N_i) > 1e-6:
                    self.correction_log.append(f"Booth {booth_id}: cell mass {total_after:.3f} != N_i {N_i:.3f}")
                if drop_cnt > 0:
                    self.correction_log.append(f"Booth {booth_id}: dropped {drop_cnt} tiny cells")

                for cell in valid_cells:
                    feats = {
                        'age_category': cell['age_cat'],
                        'religion_category': cell['religion_cat'],
                        'caste_category': cell['caste_cat'],
                        'income_category': cell['income_cat'],
                        'economic_category': row['economic_category'],
                        'locality': row['Locality'],
                        'land_rate_per_sqm': row['land_rate_per_sqm'],
                        'construction_cost_per_sqm': row['construction_cost_per_sqm'],
                        'total_population': row['TotalPop'],
                        'male_female_ratio': row.get('MaleToFemaleRatio', 1.0)
                    }
                    cell_data = {
                        'booth_id': booth_id,
                        'booth_nominal_id': row['booth_nominal_id'],
                        'booth_idx': booth_idx,
                        'cell_weight': float(cell['n_ic']),
                        'features': feats,
                        'turnout_rate': float(t_i),
                        'party_shares': party_shares
                    }
                    cell_idx = len(cells_data)
                    cells_data.append(cell_data)
                    booth_cell_indices[booth_idx].append(cell_idx)
                    booth_weights[booth_idx].append(cell['n_ic'])

        self.booth_to_cell_indices = dict(booth_cell_indices)
        self.booth_to_weights = dict(booth_weights)
        print(f"Created {len(cells_data)} cells from {len(df)} rows")
        if self.correction_log:
            print(f"Applied {len(self.correction_log)} corrections")
        return cells_data

    def prepare_features(self, cells_data, fit_transform=True):
        print(f"Preparing features (fit_transform={fit_transform})...")
        categorical_features, continuous_features = [], []
        cell_weights, booth_indices = [], []

        for cell in cells_data:
            econ_loc_interaction = f"{cell['features']['economic_category']} | {cell['features']['locality']}"
            cat = {
                'age': cell['features']['age_category'],
                'religion': cell['features']['religion_category'],
                'caste': cell['features']['caste_category'],
                'income': cell['features']['income_category'],
                'economic': cell['features']['economic_category'],
                'locality': cell['features']['locality'],
                'econ_loc': econ_loc_interaction
            }
            categorical_features.append(cat)
            cont = [
                cell['features']['land_rate_per_sqm'],
                cell['features']['construction_cost_per_sqm'],
                cell['features']['total_population'],
                cell['features']['male_female_ratio']
            ]
            continuous_features.append(cont)
            cell_weights.append(cell['cell_weight'])
            booth_indices.append(cell['booth_idx'])

        if fit_transform:
            X_cat = self.vectorizer.fit_transform(categorical_features)
            self.is_fitted = True
        else:
            if not self.is_fitted:
                raise ValueError("Vectorizer/Scaler not fitted; fit on train first.")
            X_cat = self.vectorizer.transform(categorical_features)

        X_cont = np.asarray(continuous_features, dtype=float)
        if fit_transform:
            X_cont_std = self.scaler.fit_transform(X_cont)
        else:
            X_cont_std = self.scaler.transform(X_cont)

        X = np.hstack([X_cat, X_cont_std])
        try:
            cat_names = list(self.vectorizer.get_feature_names_out())
        except AttributeError:
            cat_names = list(self.vectorizer.feature_names_)
        feature_names = cat_names + ['land_rate', 'construction_cost', 'population', 'male_female_ratio']

        return {
            'features': torch.FloatTensor(X),
            'cell_weights': torch.FloatTensor(cell_weights),
            'booth_indices': torch.LongTensor(booth_indices),
            'feature_names': feature_names
        }

# ---------------------------
# Optional: Individuals
# ---------------------------

class IndividualDataset(torch.utils.data.Dataset):
    """
    Optional micro labels. Requires fitted processor (vectorizer/scaler).
    Expected columns:
      booth_id (<PartNo>_<Year>), Year,
      age_category, religion_category, caste_category, income_category,
      economic_category, locality,
      land_rate_per_sqm, construction_cost_per_sqm, total_population, male_female_ratio,
      voted (0/1), party_label (BJP/Congress/AAP/Others/NOTA or NaN), weight (optional)
    """
    def __init__(self, df_ind: pd.DataFrame, processor: ElectoralDataProcessor):
        self.party_names = processor.party_names
        self.party_to_idx = {p: i for i, p in enumerate(self.party_names)}

        cat_dicts, conts, booth_indices, yT, yP, w = [], [], [], [], [], []
        skip_rows = 0
        for _, r in df_ind.iterrows():
            bid = str(r.get('booth_id', ''))
            if bid not in processor.booth_id_to_idx:
                skip_rows += 1
                continue
            cat_dicts.append({
                'age': r['age_category'],
                'religion': r['religion_category'],
                'caste': r['caste_category'],
                'income': r['income_category'],
                'economic': r['economic_category'],
                'locality': r['locality'],
            })
            conts.append([
                r['land_rate_per_sqm'],
                r['construction_cost_per_sqm'],
                r['total_population'],
                r.get('male_female_ratio', 1.0)
            ])
            booth_indices.append(processor.booth_id_to_idx[bid])
            yT.append(int(r['voted']))
            if pd.notna(r.get('party_label')) and int(r['voted']) == 1:
                yP.append(self.party_to_idx.get(str(r['party_label']), self.party_to_idx['Others']))
            else:
                yP.append(-1)
            w.append(float(r.get('weight', 1.0)))

        X_cat = processor.vectorizer.transform(cat_dicts) if cat_dicts else np.zeros((0, len(processor.vectorizer.feature_names_)))
        X_cont = processor.scaler.transform(np.array(conts)) if conts else np.zeros((0, 4))
        X = np.hstack([X_cat, X_cont]).astype(np.float32) if len(X_cat) else np.zeros((0, X_cat.shape[1] + X_cont.shape[1]), dtype=np.float32)

        self.X = torch.from_numpy(X)
        self.booth_idx = torch.LongTensor(booth_indices)
        self.yT = torch.FloatTensor(yT)
        self.yP = torch.LongTensor(yP)
        self.w = torch.FloatTensor(w)

        if skip_rows > 0:
            print(f"⚠️ Skipped {skip_rows} individual rows with unseen booth_id")

    def __len__(self): return self.X.shape[0]
    def __getitem__(self, i):
        return self.X[i], self.booth_idx[i], self.yT[i], self.yP[i], self.w[i]

def make_individual_dataloader(processor, path, batch_size=256, shuffle=True):
    if path is None:
        return None
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.xls', '.xlsx'):
        df_ind = pd.read_excel(path)
    else:
        df_ind = pd.read_csv(path)
    ds = IndividualDataset(df_ind, processor)
    if len(ds) == 0:
        print("⚠️ Individual dataset empty; skipping micro-loss.")
        return None
    return torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=False)

def compute_individual_loss(model, ind_batch, lambda_ind=0.0, label_smoothing=0.0):
    if ind_batch is None or lambda_ind <= 0.0:
        return torch.tensor(0.0, device=model.device)
    X, booth_idx, yT, yP, w = ind_batch
    X = X.to(model.device)
    booth_idx = booth_idx.to(model.device)
    yT = yT.to(model.device)
    yP = yP.to(model.device)
    w = w.to(model.device)

    turnout_probs, party_probs, party_log_probs = model(X, booth_idx)
    eps = 1e-12

    # Turnout BCE
    t_loss = -(yT * torch.log(turnout_probs + eps) + (1 - yT) * torch.log(1 - turnout_probs + eps))

    # Party loss for voters
    voted = (yT > 0.5)
    if voted.any():
        if label_smoothing > 0.0:
            K = party_probs.shape[1]
            target = torch.full_like(party_probs, label_smoothing/(K-1))
            target.scatter_(1, yP.clamp_min(0)[..., None], 1.0 - label_smoothing)
            p_loss = -(target[voted] * party_log_probs[voted]).sum(dim=1)
        else:
            p_loss = -party_log_probs[voted, yP[voted].clamp_min(0)]
        loss = (w * t_loss).sum() + (w[voted] * p_loss).sum()
    else:
        loss = (w * t_loss).sum()

    return lambda_ind * loss

# ---------------------------
# Training helpers
# ---------------------------

def split_booths_for_training(combined_df, test_size=0.2, random_state=42):
    unique_booth_ids = combined_df['booth_id'].unique()
    booth_years = combined_df.groupby('booth_id')['Year'].first().loc[unique_booth_ids]
    years_present = np.unique(booth_years.values)
    if len(years_present) >= 2:
        train_booths, val_booths = train_test_split(
            unique_booth_ids, test_size=test_size, random_state=random_state, stratify=booth_years
        )
    else:
        train_booths, val_booths = train_test_split(
            unique_booth_ids, test_size=test_size, random_state=random_state, shuffle=True
        )
    return train_booths, val_booths

def create_booth_batches(booth_indices, batch_size=32):
    unique_booths = torch.unique(booth_indices).tolist()
    np.random.shuffle(unique_booths)
    return [unique_booths[i:i+batch_size] for i in range(0, len(unique_booths), batch_size)]

def compute_loss_booth_batch(model, data_dict, booth_batch, booth_metadata,
                             lambda_kl=2.0, lambda_T=0.005, lambda_P=0.05,
                             lambda_bT=0.05, lambda_bP=0.2):
    booth_batch_tensor = torch.tensor(booth_batch, device=model.device)
    mask = torch.isin(data_dict['booth_indices'], booth_batch_tensor)
    if not mask.any().item():
        return torch.tensor(0.0, device=model.device)

    X = data_dict['features'][mask]
    w = data_dict['cell_weights'][mask]
    bidx = data_dict['booth_indices'][mask]

    turnout_probs, party_probs, party_log_probs = model(X, bidx)

    booth_losses = []
    for booth_idx in booth_batch:
        if booth_idx not in booth_metadata:
            continue
        m = (bidx == booth_idx)
        if not m.any().item():
            continue
        info = booth_metadata[booth_idx]
        N_i = info['N_i']
        T_i = info['T_i']
        t_i = min(info['t_i'], 1.0)
        p_i = torch.FloatTensor([info['p_i'][p] for p in model.party_names]).to(model.device)
        if N_i <= 0:
            continue

        w_i = w[m]
        t_i_probs = turnout_probs[m]
        p_i_probs = party_probs[m]

        T_hat = torch.sum(w_i * t_i_probs)
        V_hat = torch.sum(w_i.unsqueeze(1) * t_i_probs.unsqueeze(1) * p_i_probs, dim=0)

        t_hat = T_hat / N_i
        p_hat = V_hat / (T_hat + 1e-12)

        t_i_tensor = torch.tensor(t_i, device=model.device, dtype=torch.float32)
        bce = -(t_i_tensor * torch.log(t_hat + 1e-12) + (1 - t_i_tensor) * torch.log(1 - t_hat + 1e-12))
        turnout_loss = N_i * bce

        if T_i > 0:
            kl = torch.sum(p_i * torch.log((p_i + 1e-12) / (p_hat + 1e-12)))
            party_loss = T_i * lambda_kl * kl
        else:
            party_loss = torch.tensor(0.0, device=model.device)

        booth_losses.append(turnout_loss + party_loss)

    avg_loss = (sum(booth_losses) / len(booth_losses)) if booth_losses else torch.tensor(0.0, device=model.device)
    reg = (lambda_T * torch.sum(model.beta_T ** 2)
           + lambda_P * torch.sum(model.beta_P ** 2)
           + lambda_bT * torch.sum(model.booth_effects_T ** 2)
           + lambda_bP * torch.sum(model.booth_effects_P ** 2))
    return avg_loss + reg

def train_model_with_early_stopping(model, train_data, val_data, train_booth_indices, val_booth_indices,
                                   booth_metadata, epochs=1500, lr=0.001, batch_size=32,
                                   patience=75, min_delta=1e-4, ind_loader=None, lambda_ind=0.0, label_smoothing=0.0):
    optimizer = optim.Adam(model.parameters(), lr=lr)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=25, verbose=True)

    for key in ['features', 'cell_weights', 'booth_indices']:
        train_data[key] = train_data[key].to(model.device)
        val_data[key] = val_data[key].to(model.device)

    import copy
    best_val = float('inf')
    best_state = None
    best_epoch = 0
    patience_ctr = 0
    train_losses, val_losses = [], []

    ind_iter = None
    if ind_loader is not None and lambda_ind > 0.0:
        ind_iter = itertools.cycle(ind_loader)

    print(f"Starting training (epochs={epochs}, patience={patience}, lambda_ind={lambda_ind})...")
    for epoch in range(epochs):
        model.train()
        train_batches = create_booth_batches(train_booth_indices, batch_size)
        epoch_train_loss = 0.0

        for booths in train_batches:
            optimizer.zero_grad()
            agg_loss = compute_loss_booth_batch(
                model, train_data, booths, booth_metadata,
                lambda_kl=2.0, lambda_T=0.005, lambda_P=0.05, 
                lambda_bT=0.05, lambda_bP=0.2
            )
            total_loss = agg_loss
            if ind_iter is not None:
                ind_batch = next(ind_iter)
                ind_loss = compute_individual_loss(model, ind_batch, lambda_ind=lambda_ind, label_smoothing=label_smoothing)
                total_loss = total_loss + ind_loss

            if total_loss.requires_grad:
                total_loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                optimizer.step()

            epoch_train_loss += total_loss.item()

        avg_train = epoch_train_loss / max(len(train_batches), 1)

        # Validation
        model.eval()
        with torch.no_grad():
            val_batches = create_booth_batches(val_booth_indices, batch_size)
            epoch_val_loss = 0.0
            for booths in val_batches:
                loss = compute_loss_booth_batch(model, val_data, booths, booth_metadata)
                epoch_val_loss += loss.item()
            avg_val = epoch_val_loss / max(len(val_batches), 1)

        train_losses.append(avg_train)
        val_losses.append(avg_val)
        scheduler.step(avg_val)

        improved = avg_val < best_val - min_delta
        if improved:
            best_val = avg_val
            best_state = copy.deepcopy(model.state_dict())
            best_epoch = epoch
            patience_ctr = 0
        else:
            patience_ctr += 1

        if epoch % 10 == 0 or patience_ctr >= patience - 5:
            lr_now = optimizer.param_groups[0]['lr']
            print(f"Epoch {epoch:4d}: Train {avg_train:.4f} | Val {avg_val:.4f} | LR {lr_now:.2e}"
                  + ("  [BEST]" if improved else f"  [no-improve {patience_ctr}]"))

        if patience_ctr >= patience:
            print(f"Early stopping at epoch {epoch}. Restoring best epoch {best_epoch} (Val {best_val:.4f})")
            model.load_state_dict(best_state)
            break

    if best_state is not None and patience_ctr < patience:
        print(f"Training finished. Loading best epoch {best_epoch} (Val {best_val:.4f})")
        model.load_state_dict(best_state)

    return train_losses, val_losses, best_epoch

# ---------------------------
# Evaluation & Aggregation
# ---------------------------

def validate_and_calibrate(model, data_dict, booth_indices, booth_metadata, party_names):
    model.eval()
    results = {'turnout_mae': 0.0, 'turnout_rmse': 0.0, 'weighted_kl': 0.0,
               'calibration_reliability': [], 'booth_predictions': {}}
    with torch.no_grad():
        t_probs, p_probs, _ = model(data_dict['features'], data_dict['booth_indices'])
        t_probs = t_probs.detach().cpu()
        p_probs = p_probs.detach().cpu()
        w = data_dict['cell_weights'].detach().cpu()
        bidx = data_dict['booth_indices'].detach().cpu()

        obs_t, pred_t, obs_p, pred_p, weights = [], [], [], [], []
        unique_booths = torch.unique(booth_indices).tolist()

        for bi in unique_booths:
            if bi not in booth_metadata:
                continue
            m = (bidx == bi)
            if not m.any().item():
                continue
            info = booth_metadata[bi]
            N_i = info['N_i']; T_i = info['T_i']; 
            # Apply guardrail: clamp actual turnout rate
            actual_turnout_rate = min(T_i/N_i, 1.0) if N_i > 0 else 0.0
            t_i = actual_turnout_rate
            p_i = np.array([info['p_i'][p] for p in party_names])

            w_i = w[m]
            t_i_probs = t_probs[m]
            p_i_probs = p_probs[m]

            T_hat = torch.sum(w_i * t_i_probs)
            V_hat = torch.sum(w_i.unsqueeze(1) * t_i_probs.unsqueeze(1) * p_i_probs, dim=0)

            t_hat = (T_hat / N_i).item() if N_i > 0 else 0.0
            p_hat = (V_hat / (T_hat + 1e-12)).numpy()

            obs_t.append(t_i); pred_t.append(t_hat)
            obs_p.append(p_i); pred_p.append(p_hat)
            weights.append(N_i)

            results['booth_predictions'][bi] = {
                'observed_turnout': t_i, 'predicted_turnout': t_hat,
                'observed_party_shares': p_i, 'predicted_party_shares': p_hat
            }

        if obs_t:
            results['turnout_mae'] = mean_absolute_error(obs_t, pred_t, sample_weight=weights)
            results['turnout_rmse'] = np.sqrt(mean_squared_error(obs_t, pred_t, sample_weight=weights))

            total_w = sum(weights)
            wkl = 0.0
            for i in range(len(obs_p)):
                kl = np.sum(obs_p[i] * np.log((obs_p[i] + 1e-12) / (pred_p[i] + 1e-12)))
                wkl += weights[i] * kl
            results['weighted_kl'] = wkl / total_w if total_w > 0 else 0.0

            pred_arr = np.array(pred_t); obs_arr = np.array(obs_t); w_arr = np.array(weights)
            for d in range(10):
                lo, hi = d/10.0, (d+1)/10.0
                if d < 9:
                    m = (pred_arr >= lo) & (pred_arr < hi)
                else:
                    m = (pred_arr >= lo) & (pred_arr <= hi)
                if m.any():
                    ap = np.average(pred_arr[m], weights=w_arr[m])
                    ao = np.average(obs_arr[m], weights=w_arr[m])
                    results['calibration_reliability'].append({'decile': d, 'avg_predicted': ap, 'avg_observed': ao, 'count': int(m.sum())})
    return results

def aggregate_predictions(model, data_dict, booth_metadata, party_names):
    model.eval()
    out = {}
    with torch.no_grad():
        t_probs, p_probs, _ = model(data_dict['features'], data_dict['booth_indices'])
        t_probs = t_probs.detach().cpu()
        p_probs = p_probs.detach().cpu()
        w = data_dict['cell_weights'].detach().cpu()
        bidx = data_dict['booth_indices'].detach().cpu()
        unique_booths = torch.unique(bidx).tolist()

        for bi in unique_booths:
            if bi not in booth_metadata:
                continue
            m = (bidx == bi)
            if not m.any().item():
                continue
            info = booth_metadata[bi]
            N_i = info['N_i']
            if N_i <= 0: continue

            w_i = w[m]; t_i = t_probs[m]; p_i = p_probs[m]
            T_hat = torch.sum(w_i * t_i).item()
            V_hat = torch.sum(w_i.unsqueeze(1) * t_i.unsqueeze(1) * p_i, dim=0).numpy()

            t_hat = T_hat / N_i if N_i > 0 else 0.0
            p_hat = V_hat / (T_hat + 1e-12) if T_hat > 0 else np.zeros_like(V_hat)

            out[info['booth_id']] = {
                'predicted_turnout_rate': t_hat,
                'predicted_total_votes': T_hat,
                'predicted_party_votes': V_hat,
                'predicted_party_shares': p_hat,
                'total_registered': N_i
            }
    return out

def extract_coefficients(model, feature_names, party_names):
    coefficients = {'turnout': {},}
    coefficients['turnout']['intercept'] = model.alpha0.item()
    for i, fn in enumerate(feature_names):
        coefficients['turnout'][fn] = model.beta_T[i].item()

    for j, party in enumerate(party_names):
        k = f'party_{party}'
        coefficients[k] = {'intercept': model.gamma0[j].item()}
        for i, fn in enumerate(feature_names):
            coefficients[k][fn] = model.beta_P[i, j].item()

    beT = model.booth_effects_T.detach().cpu().numpy()
    beP = model.booth_effects_P.detach().cpu().numpy()
    summary = {
        'turnout_effects': {
            'mean': float(np.mean(beT)), 'std': float(np.std(beT)),
            'min': float(np.min(beT)), 'max': float(np.max(beT)),
            'top_5_positive': beT.argsort()[-5:][::-1].tolist(),
            'top_5_negative': beT.argsort()[:5].tolist()
        },
        'party_effects': {}
    }
    for j, party in enumerate(party_names):
        arr = beP[:, j]
        summary['party_effects'][party] = {
            'mean': float(np.mean(arr)), 'std': float(np.std(arr)),
            'min': float(np.min(arr)), 'max': float(np.max(arr)),
            'top_5_positive': arr.argsort()[-5:][::-1].tolist(),
            'top_5_negative': arr.argsort()[:5].tolist()
        }
    coefficients['booth_effects_summary'] = summary
    coefficients['booth_effects_turnout'] = beT
    coefficients['booth_effects_party'] = beP
    return coefficients

# ---------------------------
# Saving / Reporting
# ---------------------------

def save_cells_to_excel(cells_data, filename):
    print(f"\n📊 Saving {len(cells_data)} cells to {filename}...")
    rows = []
    for i, cell in enumerate(cells_data):
        r = {
            'cell_id': i,
            'booth_id': cell['booth_id'],
            'booth_nominal_id': cell.get('booth_nominal_id', ''),
            'booth_idx': cell['booth_idx'],
            'cell_weight': round(cell['cell_weight'], 3),
            'age_category': cell['features']['age_category'],
            'religion_category': cell['features']['religion_category'],
            'caste_category': cell['features']['caste_category'],
            'income_category': cell['features']['income_category'],
            'economic_category': cell['features']['economic_category'],
            'locality': cell['features']['locality'],
            'land_rate_per_sqm': round(cell['features']['land_rate_per_sqm'], 3),
            'construction_cost_per_sqm': round(cell['features']['construction_cost_per_sqm'], 3),
            'total_population': round(cell['features']['total_population'], 3),
            'male_female_ratio': round(cell['features']['male_female_ratio'], 3),
            'observed_turnout_rate': round(cell['turnout_rate'], 3)
        }
        for party in ['BJP', 'Congress', 'AAP', 'Others', 'NOTA']:
            r[f'observed_{party}_share'] = round(cell['party_shares'].get(party, 0.0), 3)
        rows.append(r)
    df = pd.DataFrame(rows)

    # Summary
    summary = []
    booth_counts = df.groupby('booth_id').size()
    summary.append({'Metric': 'Total_Cells', 'Value': len(df), 'Description': 'Total number of cells'})
    summary.append({'Metric': 'Average_Cells_Per_Booth', 'Value': round(booth_counts.mean(), 2),
                    'Description': 'Average cells per booth'})
    summary.append({'Metric': 'Min_Cells_Per_Booth', 'Value': int(booth_counts.min()), 'Description': 'Min cells'})
    summary.append({'Metric': 'Max_Cells_Per_Booth', 'Value': int(booth_counts.max()), 'Description': 'Max cells'})
    weights = df['cell_weight']
    summary.append({'Metric': 'Average_Cell_Weight', 'Value': round(weights.mean(), 3),
                    'Description': 'Average cell weight'})
    summary.append({'Metric': 'Total_Population_Cells', 'Value': round(weights.sum(), 0),
                    'Description': 'Sum of cell weights'})
    for cat in ['age_category', 'religion_category', 'caste_category', 'income_category']:
        summary.append({'Metric': f'Unique_{cat}', 'Value': int(df[cat].nunique()),
                        'Description': f'Unique {cat}'})
    summary_df = pd.DataFrame(summary)

    # Demographic distributions
    dist_rows = []
    for cat in ['age_category', 'religion_category', 'caste_category', 'income_category']:
        counts = df.groupby(cat)['cell_weight'].sum().sort_values(ascending=False)
        total = counts.sum()
        for k, v in counts.items():
            dist_rows.append({'category_type': cat, 'category_value': k,
                              'total_population': round(v, 0),
                              'percentage': round(v/total*100, 2)})
    dist_df = pd.DataFrame(dist_rows)

    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='All_Cells', index=False)
        summary_df.to_excel(writer, sheet_name='Summary_Statistics', index=False)
        dist_df.to_excel(writer, sheet_name='Demographic_Distributions', index=False)

        booth_summary = df.groupby('booth_id').agg({
            'cell_weight': ['count', 'sum'],
            'observed_turnout_rate': 'first',
            'age_category': 'nunique',
            'religion_category': 'nunique',
            'caste_category': 'nunique',
            'income_category': 'nunique'
        }).round(3)
        booth_summary.columns = ['cell_count', 'total_population', 'turnout_rate',
                                 'unique_age_cats', 'unique_religion_cats',
                                 'unique_caste_cats', 'unique_income_cats']
        booth_summary.to_excel(writer, sheet_name='Booth_Level_Summary')
    print(f"✅ Saved {filename}")
    return df

def save_results(model, coefficients, booth_predictions, validation_results,
                 feature_names, party_names, processor, training_info, file_prefix):
    # Model bundle (PKL) with assembly-prefixed filename
    model_data = {
        'model_state_dict': model.state_dict(),
        'model_config': {'n_features': len(feature_names), 'n_parties': len(party_names), 'n_booths': model.n_booths},
        'feature_names': feature_names,
        'party_names': party_names,
        'vectorizer': processor.vectorizer,
        'scaler': processor.scaler,
        'booth_id_to_idx': processor.booth_id_to_idx,
        'correction_log': processor.correction_log,
        'training_info': training_info
    }
    pkl_path = f"{file_prefix}trained_electoral_model.pkl"
    with open(pkl_path, 'wb') as f:
        pickle.dump(model_data, f)
    print(f"Model saved to '{pkl_path}'")

    # Coefficients workbook
    coeff_rows = []
    for mt, coeffs in coefficients.items():
        if mt.startswith('booth_effects'):  # skip arrays
            continue
        if mt == 'booth_effects_summary':
            continue
        for feat, val in coeffs.items():
            coeff_rows.append({
                'Model_Type': mt,
                'Feature': feat,
                'Coefficient': val,
                'Odds_Ratio': np.exp(val) if mt == 'turnout' else None,
                'Interpretation': 'Increases log-odds' if val > 0 else 'Decreases log-odds'
            })
    coeff_df = pd.DataFrame(coeff_rows)

    booth_sum_rows = []
    summary = coefficients['booth_effects_summary']
    booth_sum_rows.append({'Effect_Type': 'Turnout', 'Party': 'All',
                           'Mean': summary['turnout_effects']['mean'],
                           'Std': summary['turnout_effects']['std'],
                           'Min': summary['turnout_effects']['min'],
                           'Max': summary['turnout_effects']['max']})
    for party, eff in summary['party_effects'].items():
        booth_sum_rows.append({'Effect_Type': 'Party', 'Party': party,
                               'Mean': eff['mean'], 'Std': eff['std'],
                               'Min': eff['min'], 'Max': eff['max']})
    booth_summary_df = pd.DataFrame(booth_sum_rows)

    coeff_xlsx = f"{file_prefix}model_coefficients.xlsx"
    with pd.ExcelWriter(coeff_xlsx) as writer:
        coeff_df.to_excel(writer, sheet_name='Coefficients', index=False)
        booth_summary_df.to_excel(writer, sheet_name='Booth_Effects_Summary', index=False)
    print(f"Coefficients saved to '{coeff_xlsx}'")

    # Booth-level predictions + validation summary
    pred_rows = []
    for bid, pred in booth_predictions.items():
        row = {
            'booth_id': bid,
            'predicted_turnout_rate': round(pred['predicted_turnout_rate'], 3),
            'predicted_total_votes': round(pred['predicted_total_votes'], 3),
            'total_registered': round(pred['total_registered'], 3)
        }
        for i, party in enumerate(party_names):
            row[f'predicted_{party}_votes'] = round(pred['predicted_party_votes'][i], 3)
            row[f'predicted_{party}_share'] = round(pred['predicted_party_shares'][i], 3)
        pred_rows.append(row)
    predictions_df = pd.DataFrame(pred_rows)

    val_sum = pd.DataFrame([
        {'Metric': 'Turnout_MAE', 'Value': validation_results['turnout_mae']},
        {'Metric': 'Turnout_RMSE', 'Value': validation_results['turnout_rmse']},
        {'Metric': 'Weighted_KL_Divergence', 'Value': validation_results['weighted_kl']},
        {'Metric': 'Best_Epoch', 'Value': training_info.get('best_epoch', 'N/A')},
        {'Metric': 'Total_Epochs_Trained', 'Value': training_info.get('total_epochs', 'N/A')},
        {'Metric': 'Early_Stopping_Used', 'Value': training_info.get('early_stopping', False)},
    ])
    calib_df = pd.DataFrame(validation_results['calibration_reliability'])

    pred_xlsx = f"{file_prefix}booth_level_predictions.xlsx"
    with pd.ExcelWriter(pred_xlsx) as writer:
        predictions_df.to_excel(writer, sheet_name='Predictions', index=False)
        val_sum.to_excel(writer, sheet_name='Validation_Summary', index=False)
        if not calib_df.empty:
            calib_df.to_excel(writer, sheet_name='Calibration', index=False)
    print(f"Booth-level predictions saved to '{pred_xlsx}'")

    # Corrections log
    if processor.correction_log:
        log_path = f"{file_prefix}data_corrections_log.xlsx"
        pd.DataFrame({'Correction': processor.correction_log}).to_excel(log_path, index=False)
        print(f"Data corrections log saved to '{log_path}'")

def create_enhanced_all_booths_predictions(model, all_data, booth_metadata, party_names,
                                           combined_df, train_booth_ids, val_booth_ids, filename):
    print("\n📊 Creating enhanced all-booths predictions...")
    all_preds = aggregate_predictions(model, all_data, booth_metadata, party_names)
    train_set, val_set = set(train_booth_ids.tolist()), set(val_booth_ids.tolist())

    rows = []
    for bid, pred in all_preds.items():
        act = combined_df[combined_df['booth_id'] == bid].iloc[0]
        row = {
            'booth_id': bid,
            'part_no': act['PartNo'],
            'assembly_name': act['AssemblyName'],
            'locality': act['Locality'],
            'year': act['Year'],
            'data_split': 'train' if bid in train_set else 'validation',
            'total_registered': round(pred['total_registered'], 3),
            'actual_total_polled': round(act['Total_Polled'], 3),
            'predicted_total_votes': round(pred['predicted_total_votes'], 3),
            'actual_turnout_rate': round(act['Total_Polled']/act['TotalPop'], 3),
            'predicted_turnout_rate': round(pred['predicted_turnout_rate'], 3),
        }
        row['turnout_error'] = round(row['predicted_turnout_rate'] - row['actual_turnout_rate'], 3)
        row['turnout_abs_error'] = round(abs(row['turnout_error']), 3)

        for i, party in enumerate(party_names):
            actual_share = act[f'{party}_Ratio']
            predicted_share = pred['predicted_party_shares'][i]
            actual_votes = act['Total_Polled'] * actual_share
            predicted_votes = pred['predicted_party_votes'][i]
            row[f'actual_{party}_share'] = round(actual_share, 3)
            row[f'predicted_{party}_share'] = round(predicted_share, 3)
            row[f'actual_{party}_votes'] = round(actual_votes, 3)
            row[f'predicted_{party}_votes'] = round(predicted_votes, 3)
            row[f'{party}_share_error'] = round(predicted_share - actual_share, 3)
            row[f'{party}_share_abs_error'] = round(abs(predicted_share - actual_share), 3)
        row.update({
            'economic_category': act['economic_category'],
            'land_rate_per_sqm': round(act['land_rate_per_sqm'], 3),
            'construction_cost_per_sqm': round(act['construction_cost_per_sqm'], 3),
            'male_female_ratio': round(act.get('MaleToFemaleRatio', 1.0), 3),
        })
        rows.append(row)

    df = pd.DataFrame(rows)

    # Summary stats
    summary = []
    for name, mask in [('Overall', slice(None)),
                       ('Training', df['data_split'] == 'train'),
                       ('Validation', df['data_split'] == 'validation')]:
        subset = df if isinstance(mask, slice) else df[mask]
        if len(subset) == 0: continue
        summary.append({'data_split': name, 'metric': 'Turnout_MAE',
                        'value': round(subset['turnout_abs_error'].mean(), 4),
                        'description': 'Mean Absolute Error (turnout rate)'})
        summary.append({'data_split': name, 'metric': 'Turnout_RMSE',
                        'value': round(np.sqrt((subset['turnout_error']**2).mean()), 4),
                        'description': 'RMSE (turnout rate)'})
        for party in party_names:
            summary.append({'data_split': name, 'metric': f'{party}_Share_MAE',
                            'value': round(subset[f'{party}_share_abs_error'].mean(), 4),
                            'description': f'MAE for {party} share'})
    summary_df = pd.DataFrame(summary)

    # Error analysis
    err_rows = []
    for econ in df['economic_category'].dropna().unique():
        sub = df[df['economic_category'] == econ]
        if len(sub) == 0: continue
        err_rows.append({'category_type': 'Economic', 'category_value': econ,
                         'booth_count': len(sub),
                         'avg_turnout_error': round(sub['turnout_abs_error'].mean(), 4),
                         'avg_total_party_error': round(sum(sub[f'{p}_share_abs_error'].mean() for p in party_names), 4)})
    for split in ['train', 'validation']:
        sub = df[df['data_split'] == split]
        if len(sub) == 0: continue
        err_rows.append({'category_type': 'Data_Split', 'category_value': split,
                         'booth_count': len(sub),
                         'avg_turnout_error': round(sub['turnout_abs_error'].mean(), 4),
                         'avg_total_party_error': round(sum(sub[f'{p}_share_abs_error'].mean() for p in party_names), 4)})
    for year in df['year'].unique():
        sub = df[df['year'] == year]
        err_rows.append({'category_type': 'Year', 'category_value': str(year),
                         'booth_count': len(sub),
                         'avg_turnout_error': round(sub['turnout_abs_error'].mean(), 4),
                         'avg_total_party_error': round(sum(sub[f'{p}_share_abs_error'].mean() for p in party_names), 4)})
    err_df = pd.DataFrame(err_rows)

    # Comparison sheet
    comp_rows = []
    for _, r in df.iterrows():
        comp_rows.append({'booth_id': r['booth_id'], 'metric_type': 'Turnout_Rate',
                          'actual': r['actual_turnout_rate'], 'predicted': r['predicted_turnout_rate'],
                          'error': r['turnout_error'], 'abs_error': r['turnout_abs_error'],
                          'data_split': r['data_split']})
        for p in party_names:
            comp_rows.append({'booth_id': r['booth_id'], 'metric_type': f'{p}_Share',
                              'actual': r[f'actual_{p}_share'], 'predicted': r[f'predicted_{p}_share'],
                              'error': r[f'{p}_share_error'], 'abs_error': r[f'{p}_share_abs_error'],
                              'data_split': r['data_split']})
    comp_df = pd.DataFrame(comp_rows)

    with pd.ExcelWriter(filename, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name='All_Predictions_Enhanced', index=False)
        summary_df.to_excel(writer, sheet_name='Summary_Statistics', index=False)
        err_df.to_excel(writer, sheet_name='Error_Analysis', index=False)
        comp_df.to_excel(writer, sheet_name='Actual_vs_Predicted', index=False)
    print(f"✅ Enhanced predictions saved to '{filename}'")
    return df, summary_df, err_df

# ---------------------------
# Main
# ---------------------------

def main(use_early_stopping=True, max_epochs=1500, patience=75,
         file_2025=r'C:\Users\kushp\Downloads\testing\Delhi election Model\Aggregate Data\Assembly01_Nerela_2025.xlsx',
         file_2020=None,
         individual_labels_path=None,
         lambda_ind=0.0, label_smoothing=0.0):
    print("=== ENHANCED ELECTORAL PREDICTION MODEL ===")
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")

    processor = ElectoralDataProcessor()

    # 1) Load + clean
    print("\n1) Loading datasets...")
    combined_df = processor.load_and_combine_data(file_2025=file_2025, file_2020=file_2020)

    # Prefix for file outputs based on Assembly
    file_prefix = derive_assembly_name_prefix(combined_df)

    # 2) Split booths
    print("\n2) Splitting booths...")
    train_booth_ids, val_booth_ids = split_booths_for_training(combined_df, test_size=0.2)
    print(f"Train booths: {len(train_booth_ids)}, Val booths: {len(val_booth_ids)}")

    # 3) Construct cells
    print("\n3) Constructing cells...")
    cells_data = processor.construct_cells(combined_df)

    # 4) Save cells
    print("\n4) Saving cells Excel...")
    _ = save_cells_to_excel(cells_data, f"{file_prefix}demographic_cells_data.xlsx")

    # 5) Split cells into train/val by booth
    print("\n5) Splitting cells by booth...")
    train_set, val_set = set(train_booth_ids.tolist()), set(val_booth_ids.tolist())
    train_cells = [c for c in cells_data if c['booth_id'] in train_set]
    val_cells = [c for c in cells_data if c['booth_id'] in val_set]
    print(f"Train cells: {len(train_cells)}, Val cells: {len(val_cells)}")

    # 6) Prepare features
    print("\n6) Preparing features...")
    train_data = processor.prepare_features(train_cells, fit_transform=True)
    val_data = processor.prepare_features(val_cells, fit_transform=False)
    train_booth_indices = torch.unique(train_data['booth_indices'])
    val_booth_indices = torch.unique(val_data['booth_indices'])

    # 7) Init model
    print("\n7) Initializing model...")
    n_features = train_data['features'].shape[1]
    n_parties = len(processor.party_names)
    n_booths = len(processor.booth_id_to_idx)
    print(f"Model: {n_features} features, {n_parties} parties, {n_booths} booths")
    model = AggregateVotingModel(n_features, n_parties, n_booths, device=device).to(device)

    # Optional individuals: create loader AFTER fitting encoders on train
    ind_loader = make_individual_dataloader(processor, individual_labels_path, batch_size=256) \
                 if (individual_labels_path and lambda_ind > 0.0) else None

    # 8) Train
    print(f"\n8) Training (early_stopping={use_early_stopping}, lambda_ind={lambda_ind})...")
    if use_early_stopping:
        train_losses, val_losses, best_epoch = train_model_with_early_stopping(
            model, train_data, val_data, train_booth_indices, val_booth_indices,
            processor.booth_metadata, epochs=max_epochs, patience=patience,
            ind_loader=ind_loader, lambda_ind=lambda_ind, label_smoothing=label_smoothing
        )
        training_info = {
            'early_stopping': True,
            'best_epoch': best_epoch,
            'total_epochs': len(train_losses),
            'max_epochs': max_epochs,
            'patience': patience
        }
    else:
        # Fallback simple training (optional): omitted for brevity; early stopping is recommended.
        train_losses, val_losses, best_epoch = train_model_with_early_stopping(
            model, train_data, val_data, train_booth_indices, val_booth_indices,
            processor.booth_metadata, epochs=max_epochs, patience=patience,
            ind_loader=ind_loader, lambda_ind=lambda_ind, label_smoothing=label_smoothing
        )
        training_info = {'early_stopping': True, 'best_epoch': best_epoch, 'total_epochs': len(train_losses)}

    # 9) Validation
    print("\n9) Validation & calibration...")
    validation_results = validate_and_calibrate(model, val_data, val_booth_indices, processor.booth_metadata, processor.party_names)

    # 10) Predictions (val)
    print("\n10) Aggregating predictions (validation)...")
    val_booth_predictions = aggregate_predictions(model, val_data, processor.booth_metadata, processor.party_names)

    # 11) Coefficients
    print("\n11) Extracting coefficients...")
    coefficients = extract_coefficients(model, train_data['feature_names'], processor.party_names)

    # 12) Save results (assembly-prefixed files, incl. PKL)
    print("\n12) Saving results...")
    save_results(
        model, coefficients, val_booth_predictions, validation_results,
        train_data['feature_names'], processor.party_names, processor, training_info,
        file_prefix=file_prefix
    )

    # 13) Enhanced predictions for all booths
    print("\n13) Enhanced predictions for all booths...")
    all_data = processor.prepare_features(cells_data, fit_transform=False)
    _enhanced_df, _summary_df, _err_df = create_enhanced_all_booths_predictions(
        model, all_data, processor.booth_metadata, processor.party_names,
        combined_df, train_booth_ids, val_booth_ids,
        filename=f"{file_prefix}enhanced_all_booth_predictions.xlsx"
    )

    print("\n=== DONE ===")
    print(f"Final Train Loss: {train_losses[-1]:.4f} | Final Val Loss: {val_losses[-1]:.4f}")
    print(f"Turnout MAE: {validation_results['turnout_mae']:.4f} | RMSE: {validation_results['turnout_rmse']:.4f} | Weighted KL: {validation_results['weighted_kl']:.4f}")
    print("\n📁 FILES CREATED (assembly-prefixed):")
    print(f"  - {file_prefix}demographic_cells_data.xlsx")
    print(f"  - {file_prefix}enhanced_all_booth_predictions.xlsx")
    print(f"  - {file_prefix}trained_electoral_model.pkl")
    print(f"  - {file_prefix}model_coefficients.xlsx")
    print(f"  - {file_prefix}booth_level_predictions.xlsx")
    print(f"  - {file_prefix}data_corrections_log.xlsx (if any corrections)")

    return model, coefficients, val_booth_predictions, validation_results, training_info

# ---------------------------
# Quick validation helper (optional)
# ---------------------------

def quick_validation_test(file_2025=r'C:\Users\kushp\Downloads\testing\Delhi election Model\Aggregate Data\Assembly01_Nerela_2025.xlsx'):
    print("=== QUICK COLUMN VALIDATION TEST (2025) ===")
    try:
        df = pd.read_excel(file_2025)
        proc = ElectoralDataProcessor()
        print(f"Total columns: {len(df.columns)}")
        _ = proc.validate_data_columns(df.assign(Year=2025))  # add Year for validation shape
        print("✅ Column validation passed (structure only).")
        return True
    except Exception as e:
        print(f"❌ Validation error: {e}")
        return False

# ---------------------------
# Entry
# ---------------------------

if __name__ == "__main__":
    # Example usage:
    # - Only 2025 aggregate data (no 2020; no individuals)
    # - To enable individuals, set individual_labels_path and lambda_ind > 0.0
    if quick_validation_test():
        model, coefficients, predictions, validation, training_info = main(
            use_early_stopping=True,
            max_epochs=1500,
            patience=75,
            file_2025=r'C:\Users\kushp\Downloads\testing\Delhi election Model\Aggregate Data\Assembly01_Nerela_2025.xlsx',
            file_2020=None,                      # optional
            individual_labels_path=None,         # optional
            lambda_ind=0.0,                      # 0 = off
            label_smoothing=0.0
        )
    else:
        print("❌ Please fix columns in your 2025 dataset and re-run.")
